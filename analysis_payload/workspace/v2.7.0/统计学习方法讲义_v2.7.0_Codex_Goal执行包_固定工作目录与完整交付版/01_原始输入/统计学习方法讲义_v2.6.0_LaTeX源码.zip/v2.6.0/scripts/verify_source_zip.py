#!/usr/bin/env python3
"""Verify the final v2.6.0 source ZIP structure and extracted build plan."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT.parent.parent.parent / "统计学习方法讲义_v2.6.0_LaTeX源码.zip"
OUTPUT = ROOT.parent.parent.parent / "logs" / "source_zip_verification.json"


def safe_members(zf: zipfile.ZipFile) -> list[str]:
    names: list[str] = []
    for info in zf.infolist():
        path = PurePosixPath(info.filename)
        if path.is_absolute() or ".." in path.parts:
            raise RuntimeError(f"unsafe ZIP entry: {info.filename}")
        if not path.parts or path.parts[0] != "v2.6.0":
            raise RuntimeError(f"entry outside v2.6.0 prefix: {info.filename}")
        names.append(info.filename)
    return names


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--full-rebuild",
        action="store_true",
        help="also rebuild the extracted archive from a clean ASCII temporary directory",
    )
    args = parser.parse_args()
    if not ARCHIVE.is_file():
        raise FileNotFoundError(ARCHIVE)
    full_rebuild = None
    with zipfile.ZipFile(ARCHIVE) as zf:
        names = safe_members(zf)
        bad_crc = zf.testzip()
        if bad_crc is not None:
            raise RuntimeError(f"ZIP CRC verification failed at {bad_crc}")

        forbidden = [
            name for name in names
            if any(
                part in {
                    ".git", ".worktrees", "build", "build-output", "node_modules",
                    "previews", "rendered", "tmp",
                }
                or part.startswith(".slbuild-")
                for part in PurePosixPath(name).parts
            )
        ]
        main_files = [name for name in names if name.endswith("/main_full.tex")]
        chapter_files = [
            name for name in names
            if PurePosixPath(name).name.startswith("V")
            and "-C" in PurePosixPath(name).name
            and name.endswith(".tex")
            and "/chapters/" in name
        ]
        style_files = [name for name in names if name.endswith("/common/statlearnbook.sty")]
        shared_style_files = [name for name in names if name.endswith("/styles/figure-style-v2.3.1.tex")]
        required = [
            "v2.6.0/build_v2.6.0.ps1",
            "v2.6.0/README_v2.6.0.md",
            "v2.6.0/AGENTS.md",
            "v2.6.0/figures/figure_manifest.csv",
            "v2.6.0/manifests/release_pdf_name.txt",
            "v2.6.0/manifests/v2.3.1_figure_source_map.csv",
            "v2.6.0/manifests/v2.3.1_figure_implementation_status.csv",
            "v2.6.0/styles/figure-style-v2.3.1.tex",
            "v2.6.0/src/绘图源码/前置页/UFIG-P001-01.tex",
            "v2.6.0/src/绘图源码/第01册_数学基础与统计学习基本理论/V1-C10/UFIG-P158-01.tex",
        ]
        missing_required = [name for name in required if name not in names]

        if forbidden or len(main_files) != 1 or len(chapter_files) != 37 or len(style_files) != 1 or len(shared_style_files) != 1 or missing_required:
            raise RuntimeError(
                "source ZIP structural verification failed: "
                f"forbidden={len(forbidden)}, main={len(main_files)}, "
                f"chapters={len(chapter_files)}, styles={len(style_files)}, shared_styles={len(shared_style_files)}, missing={missing_required}"
            )

        with tempfile.TemporaryDirectory(prefix="statlearn-v2-zip-") as temp_name:
            temp = Path(temp_name)
            zf.extractall(temp)
            extracted_root = temp / "v2.6.0"

            # The implementation-status manifest is the authoritative list of
            # the 101 formal figures.  A source-level UID comment is useful
            # provenance, but it is not mandatory for every legacy module and
            # therefore must not be used as the release completeness gate.
            status_path = extracted_root / "manifests" / "v2.3.1_figure_implementation_status.csv"
            source_map_path = extracted_root / "manifests" / "v2.3.1_figure_source_map.csv"
            with status_path.open("r", encoding="utf-8-sig", newline="") as handle:
                status_rows = list(csv.DictReader(handle))
            formal_uids = [row["figure_uid"].strip() for row in status_rows]
            uid_pattern = re.compile(r"^(?:FIG|UFIG)-P\d{3}-\d{2}$")
            if len(formal_uids) != 101 or len(set(formal_uids)) != 101:
                raise RuntimeError(
                    f"expected 101 unique formal figure UIDs; "
                    f"found rows={len(formal_uids)}, unique={len(set(formal_uids))}"
                )
            invalid_uids = [uid for uid in formal_uids if not uid_pattern.fullmatch(uid)]
            if invalid_uids:
                raise RuntimeError(f"invalid formal figure UIDs: {invalid_uids}")
            missing_sources = []
            for row in status_rows:
                source_rel = row["source_tex_file"].strip().replace("\\", "/")
                if not source_rel or not (extracted_root / PurePosixPath(source_rel)).is_file():
                    missing_sources.append({"figure_uid": row["figure_uid"], "source": source_rel})
            if missing_sources:
                raise RuntimeError(f"formal figure sources missing from ZIP: {missing_sources}")

            with source_map_path.open("r", encoding="utf-8-sig", newline="") as handle:
                source_map_rows = list(csv.DictReader(handle))
            mapped_formal_uids = {
                row["figure_uid"].strip()
                for row in source_map_rows
                if uid_pattern.fullmatch(row["figure_uid"].strip())
            }
            if mapped_formal_uids != set(formal_uids):
                raise RuntimeError(
                    "formal figure UID set differs between implementation status and source map: "
                    f"status_only={sorted(set(formal_uids) - mapped_formal_uids)}, "
                    f"source_map_only={sorted(mapped_formal_uids - set(formal_uids))}"
                )

            marker_count = 0
            for tex_path in (extracted_root / "src" / "绘图源码").rglob("*.tex"):
                marker_count += tex_path.read_text(encoding="utf-8").count("v2.3.1 figure UID:")
            powershell = shutil.which("powershell") or shutil.which("powershell.exe")
            if powershell is None:
                raise RuntimeError("powershell executable not found for extracted DryRun")
            completed = subprocess.run(
                [
                    powershell,
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(extracted_root / "build_v2.6.0.ps1"),
                    "-DryRun",
                ],
                cwd=extracted_root,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=120,
            )
            if completed.returncode != 0:
                raise RuntimeError(f"extracted DryRun failed: {completed.stderr.strip()}")
            plan = json.loads(completed.stdout)
            if plan.get("target") != "merged_full" or plan.get("automatic_install") is not False:
                raise RuntimeError(f"unexpected extracted build plan: {plan}")

            if args.full_rebuild:
                rebuilt = subprocess.run(
                    [
                        powershell,
                        "-ExecutionPolicy",
                        "Bypass",
                        "-File",
                        str(extracted_root / "build_v2.6.0.ps1"),
                        "-Engine",
                        "lualatex",
                        "-Clean",
                        "-NoPublish",
                    ],
                    cwd=extracted_root,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=1800,
                )
                if rebuilt.returncode != 0:
                    tail = (rebuilt.stdout + "\n" + rebuilt.stderr)[-8000:]
                    raise RuntimeError(f"extracted full rebuild failed with {rebuilt.returncode}:\n{tail}")
                rebuilt_pdf = extracted_root / "build" / "final" / "main_full.pdf"
                rebuilt_log = extracted_root / "build" / "final" / "main_full.log"
                if not rebuilt_pdf.is_file() or not rebuilt_log.is_file():
                    raise RuntimeError("extracted full rebuild did not produce PDF and log")
                log_text = rebuilt_log.read_text(encoding="utf-8", errors="replace")
                page_matches = re.findall(r"Output written on main_full\.pdf \((\d+) pages,", log_text)
                rebuilt_pages = int(page_matches[-1]) if page_matches else 0
                bad_log_patterns = {
                    "tex_error": r"(?m)^!|LaTeX Error|Package .* Error",
                    "undefined_control": r"Undefined control sequence",
                    "fatal": r"Emergency stop|Fatal error",
                    "overfull": r"Overfull \\[hv]box",
                    "underfull": r"Underfull \\[hv]box",
                    "undefined_references": r"There were undefined references",
                }
                bad_log_matches = {
                    name: len(re.findall(pattern, log_text, flags=re.IGNORECASE))
                    for name, pattern in bad_log_patterns.items()
                }
                if rebuilt_pages != 879 or any(bad_log_matches.values()):
                    raise RuntimeError(
                        f"extracted full rebuild audit failed: pages={rebuilt_pages}, "
                        f"log_matches={bad_log_matches}"
                    )
                full_rebuild = {
                    "result": "PASS",
                    "engine": "lualatex",
                    "clean_build": True,
                    "reused_worktree_cache": False,
                    "page_count": rebuilt_pages,
                    "pdf_bytes": rebuilt_pdf.stat().st_size,
                    "log_bad_matches": bad_log_matches,
                }

    result = {
        "schema_version": 1,
        "archive": ARCHIVE.name,
        "archive_bytes": ARCHIVE.stat().st_size,
        "zip_entries": len(names),
        "crc_failure": None,
        "safe_paths": True,
        "forbidden_entries": 0,
        "main_full_tex": len(main_files),
        "chapter_files": len(chapter_files),
        "authoritative_style_files": len(style_files),
        "shared_figure_style_files": len(shared_style_files),
        "formal_figure_records": len(formal_uids),
        "unique_formal_figure_uids": len(set(formal_uids)),
        "formal_figure_sources_present": len(formal_uids) - len(missing_sources),
        "formal_figure_uid_sets_match": True,
        "source_uid_comment_markers_informational": marker_count,
        "required_files_present": True,
        "extracted_dry_run": "PASS",
        "dry_run_target": plan["target"],
        "dry_run_engine": plan["engine"],
        "network_required": plan["network_required"],
        "automatic_install": plan["automatic_install"],
        "full_rebuild_repeated": bool(args.full_rebuild),
        "full_rebuild": full_rebuild,
        "result": "PASS",
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
