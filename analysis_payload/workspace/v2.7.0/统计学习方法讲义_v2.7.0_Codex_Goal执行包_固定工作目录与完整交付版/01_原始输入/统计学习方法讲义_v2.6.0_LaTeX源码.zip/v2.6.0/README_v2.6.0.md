# 《统计学习方法初学者讲义》v2.6.0 源码说明

本源码包可在 Windows PowerShell 中离线重建五册合并总册。正式入口唯一定位为：

```text
src\讲义源码\合并总册\main_full.tex
```

## 构建环境

- Windows PowerShell 5.1 或更高版本；
- TeX Live 2026 或功能等价发行版；
- LuaLaTeX、`latexmk`、`makeindex`；
- 西文正文依次回退 `STIX Two Text`、`Libertinus Serif`、`TeX Gyre Termes`；数学字体依次回退 `STIX Two Math`、`Libertinus Math`、`TeX Gyre Termes Math`；
- 无衬线字体使用 TeX Live 自带的 `TeX Gyre Heros`；中文字体依次回退 Noto Serif/Sans SC、Source Han Serif/Sans SC、Fandol；
- 构建不需要网络，也不会自动安装或分发软件、宏包或字体。

## 一键干净构建

在解压后的 `v2.6.0` 目录运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\build_v2.6.0.ps1 -Engine lualatex -Clean
```

成功后生成：

```text
统计学习方法初学者讲义_合并总册v2.6.0_完整解析版.pdf
```

若只需验收、不发布顶层 PDF，可增加 `-NoPublish`。如构建被外部时限中断，确认没有残留 TeX 进程且源码未变后，可改用 `-Resume` 续跑。查看解析后的构建计划而不写产物：

```powershell
powershell -ExecutionPolicy Bypass -File .\build_v2.6.0.ps1 -DryRun
```

## 源码结构

- `src\讲义源码`：五册共 37 章、合并入口与公共 LaTeX 样式；
- `src\绘图源码`：101 幅正式 TikZ/PGFPlots 绘图源；
- `styles\figure-style-v2.3.1.tex`：沿用的稳定公共绘图样式文件名；历史文件名用于降低迁移风险，不代表发布版本；
- `manifests`：发布文件名、逐图源映射与历史实施状态；
- `scripts`：源码包结构验证与辅助审计脚本。

源码包不包含构建缓存、预览图、执行状态目录、Git 元数据或生成 PDF。
